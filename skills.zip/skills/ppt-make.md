---
name: ppt-make
description: 用户给出一个主题后，先联网深度检索收集素材与数据，再整理成事实清单和大纲，最后调用 pptx 技能生成 .pptx 演示文稿。当用户说"做个PPT""生成幻灯片""做份汇报/演示文稿""围绕XX主题做个deck"时使用。
whenToUse: 用户给出一个主题、题目或一句话需求，要求产出 PPT / 幻灯片 / 演示文稿 / 汇报材料时。
user-invocable: true
---

# 主题 → 检索 → PPT

一条流水线：**先查清楚，再动手做**。禁止跳过检索直接编内容，也禁止拿模型的记忆当事实。

```
主题  ──►  ① 需求确认  ──►  ② 联网检索  ──►  ③ 素材+大纲  ──►  ④ 调用 pptx 技能  ──►  ⑤ 校验交付
                                    │                                    │
                              落盘 素材.md                        落盘 大纲.md
```

## 0. 配置

| 项目 | 默认值 |
|---|---|
| 输出根目录 | `D:\xuexi\PPT\` |
| 本次工作目录 | `D:\xuexi\PPT\<主题>\` |
| 素材文件 | `<工作目录>\素材.md` |
| 大纲文件 | `<工作目录>\大纲.md` |
| 构建目录 | `<工作目录>\build\`（放 `gen.js`、`node_modules`、中间产物） |
| 成品 | `<工作目录>\<主题>.pptx` |
| 默认页数 | 10~14 页（封面 1 + 目录 1 + 正文 8~10 + 结尾 1） |
| 默认语言 | 中文 |

主题名里不能做文件名的字符（`\ / : * ? " < > |`）换成 `_`，长度截到 50 字以内。

## 1. 需求确认

主题明确、页数没要求时**不要追问**，按默认值直接开工，并在第一次回复里说明你采用的默认。

只有下面这种含糊情况才用 `AskUserQuestion` 问一次（最多两个问题）：

| 情况 | 问什么 |
|---|---|
| 主题大到无法收敛（如"AI"“中国历史”） | 具体切入角度 / 用途场景 |
| 用途不明且会改变内容取向 | 给谁看（课堂汇报 / 商业路演 / 科普分享） |
| 用户明确提到页数或时长 | 只确认页数，其余按默认 |

用途会实质影响内容：**课堂汇报**重概念与例子，**商业路演**重痛点与数据，**科普分享**重故事与类比。确认不了就按"给普通听众的科普汇报"处理。

## 2. 联网检索（本技能的核心，不许省）

用 `WebSearch` + `WebFetch`。至少跑满下面 4 轮，每轮再拆 2~3 个查询；单轮搜完就收手视为不合格。

| 轮次 | 目标 | 查询示例（把 `<T>` 换成主题） |
|---|---|---|
| 1 · 全貌 | 定义、范畴、为什么重要 | `<T> 是什么`、`<T> 概述`、`introduction to <T>` |
| 2 · 事实与数据 | 关键数字、时间线、权威报告 | `<T> 市场规模 2026`、`<T> 统计数据`、`<T> report` |
| 3 · 最新进展 | 近 12 个月的动态 | `<T> 2026 最新`、`<T> 进展`、`<T> news` |
| 4 · 争议与风险 | 批评、局限、对立观点、失败案例 | `<T> 挑战`、`<T> 争议`、`<T> 局限`、`<T> criticism` |

检索纪律：

- **每个要上台面的事实都必须能追到一个 URL。** 追不到的，要么删掉，要么明确标为"待核实"。
- **数字类结论至少两个独立来源交叉验证。** 来源之间不一致时，两个都写下来并注明分歧，不要擅自挑一个。
- **时效性**：优先近 12 个月的一手来源（官方报告、机构官网、权威媒体）。引用时写清数据所属年份，不要把 2019 年的数据当 2026 年的现状讲。
- **来源质量**：优先官方 / 学术 / 头部媒体；自媒体、论坛、内容农场只用于找线索，不作为出处。
- 中文主题优先中文源，国际性主题（科技、市场、学术）补充英文源。
- `WebFetch` 只取摘要不够——把关键页面真正读进去，拿到可引用的原句和数字。

## 3. 整理素材与大纲

### 3.1 落盘 `素材.md`

```markdown
# <主题> · 检索素材

检索时间：<YYYY-MM-DD>　检索轮次：N 轮　来源数：M

## 一、事实清单
| # | 事实/结论 | 关键数据 | 年份 | 来源 | 可信度 |
|---|---|---|---|---|---|
| 1 | …… | …… | 2026 | <URL> | 高（官方） |
| 2 | …… | …… | 2025 | <URL> | 中（单一来源） |

## 二、时间线
- <年份>：<事件>

## 三、争议与风险
- <观点 A>（来源）　vs　<观点 B>（来源）

## 四、未核实 / 存疑项
- <内容> —— 原因
```

**可信度**一栏必须诚实标注：两个以上独立来源记为"高"，单一来源记"中"，只有一条且来源一般记"低"。低可信度的内容不上正文页，或上了必须在讲者备注里写明。

### 3.2 落盘 `大纲.md`

每一页都要写全这 5 项，缺一项都不算完成：

```markdown
## 第 N 页 · <页面标题>
- **版式**：<封面 / 目录 / 双栏·左文右图 / 图标行 / 2x2 网格 / 大数字 / 时间线 / 对比栏 / 结尾>
- **要点**：
  1. <要点，≤ 20 字>
  2. ……
  3. ……
- **视觉元素**：<图标 / 原生图表（类型 + 数据）/ 大数字 / 图片>
- **数据出处**：<对应 素材.md 的 #编号 和 URL>
- **讲者备注**：<这一页口头补充什么，1~2 句>
```

大纲硬约束：

- **一页一个观点**，要点不超过 5 条，每条不超过 20 字。写不下就拆页，不要缩字号。
- **不许连续两页用同一版式**，至少准备 4 种版式轮换。
- **不许有纯文字页**，每页都要有一个视觉元素。
- 结构通常是：封面 → 目录 → 背景/定义 → 数据现状 → 核心内容 2~4 页 → 争议与挑战 → 展望 → 结论/致谢。
- 大纲写完后，把每页"要点"字段通读一遍，检查是否与 `素材.md` 一致——**大纲里出现的任何数字都必须能在素材里找到出处**。

## 4. 调用 pptx 技能生成

**把上面两份文件交出去，不要只甩一句"做个PPT"。** 调用时一并给出：

- `大纲.md` 的完整路径（这是唯一的内容依据）
- `素材.md` 的路径（核对数据用）
- 成品输出路径、受众与用途、期望页数
- 明确要求：**先在本机把依赖装好**（见第 6 节），生成后跑 `validate.py`

调用方式：

1. 优先用 `Skill` 工具调用 `pptx`；
2. 若技能列表里没有 `pptx`，直接读 `D:\xuexi\.dsh\skills\pptx\SKILL.md`，按里面的指引照做（该技能已装在 `D:\xuexi\.dsh\skills\pptx\`，附完整 `scripts/`）。

生成工作全部放在 `build\` 目录里做，最终 `.pptx` 再落到工作目录根下。

## 5. 校验与交付

### 5.1 文件结构校验（必做）

在 `build\` 目录里先备好解释器和依赖（只需一次）：

```bash
cd "D:/xuexi/PPT/<主题>/build"
PY="C:/Users/jsk/.dsh/dsh-runtimes/dsh-primary-runtime/dependencies/python/python.exe"
"$PY" -m pip install --quiet --target ./deps defusedxml
```

再校验（`PYTHONUTF8=1` 不能少，原因见第 6 节）：

```bash
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 PYTHONPATH="./deps" \
  "$PY" "D:/xuexi/.dsh/skills/pptx/scripts/office/validate.py" "output.pptx"
```

通过时输出 `All validations PASSED!`。出现 `FAILED` 就回生成脚本里改，**不要手改打包好的 XML**。

### 5.2 内容校验（必做）

本机没装 `markitdown`（且它依赖 onnxruntime，很重），改用运行时自带的 python-pptx 导出文字：

先写 `build\dump.py`：

```python
import sys
from pptx import Presentation

prs = Presentation(sys.argv[1])
for i, slide in enumerate(prs.slides, 1):
    print(f"\n<!-- slide {i} -->")
    for sh in slide.shapes:
        if sh.has_text_frame and sh.text_frame.text.strip():
            for para in sh.text_frame.paragraphs:
                t = "".join(r.text for r in para.runs).strip()
                if t:
                    print(f"  {t}")
        if sh.has_table:
            for row in sh.table.rows:
                print("  | " + " | ".join(c.text.strip() for c in row.cells) + " |")
    if slide.has_notes_slide and slide.notes_slide.notes_text_frame.text.strip():
        print(f"  [备注] {slide.notes_slide.notes_text_frame.text.strip()}")
```

再跑，**输出重定向到文件**，然后读文件（Git Bash 控制台是 GBK，直接打中文会乱码）：

```bash
PYTHONUTF8=1 PYTHONIOENCODING=utf-8 "$PY" build/dump.py output.pptx > build/dump.txt
```

逐页核对：**有没有缺内容、错别字、顺序错乱、上一版残留的占位文字。**

### 5.3 视觉校验（本机不可用，如实说明）

本机 **没装 LibreOffice，也没有 pdftoppm**，`soffice.py --convert-to pdf` 那条路走不通，因此**无法做渲染层面的视觉检查**。不要假装做过。替代办法：

- 生成时就守住硬约束：正文 14~16pt、标题 36~44pt，页边距 ≥ 0.5"，块间距 0.3" 或 0.5"，文本框留 10~20% 余量。
- 用 5.2 的导出结果逐页数**字数**，估算是否可能溢出，超了就缩内容而不是缩字号。
- 在最终交付里明确写一句："本机无 LibreOffice，未做视觉渲染校验。"

### 5.4 交付

回复里给出：

1. 成品 `.pptx` 的可点击路径
2. 页数、采用的版式与配色
3. 一句话说明数据来源构成（几个来源、什么时间检索的）
4. 明确列出**没做到的部分**（如未做视觉校验、哪些数据存疑）
5. 两个中间文件（`素材.md`、`大纲.md`）的路径

## 6. 本机环境备忘（已实测，照抄即可）

| 事项 | 结论 |
|---|---|
| 技能目录 | `D:\xuexi\.dsh\skills\`，扁平 `.md` 和文件夹式技能都能用 |
| pptx 技能 | 已装在 `D:\xuexi\.dsh\skills\pptx\`（含 `scripts/`） |
| **Python** | **必须用 dsh 运行时 Python**：`C:\Users\jsk\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\python\python.exe` |
| 系统 Python | 是空的（无 lxml / Pillow / python-docx），**不要用** |
| python-pptx | 1.0.2，运行时 Python 已自带 |
| pptxgenjs | **未预装**，需在构建目录执行 `npm install pptxgenjs`（约 2 分钟，19 个包） |
| markitdown | 未装且很重（拉 onnxruntime），别装，用 python-pptx 导出替代 |
| defusedxml | 未装，`validate.py` 需要它：`"$PY" -m pip install --target ./deps defusedxml`，再设 `PYTHONPATH=./deps` |
| **中文编码坑** | 本机 locale 是 GBK，`validate.py` 会报 `'gbk' codec can't decode byte`。**必须加 `PYTHONUTF8=1`**，加完即通过 |
| LibreOffice / pdftoppm | 均未安装，视觉渲染校验不可用 |

`pptxgenjs` 的 API 陷阱（配色不带 `#`、`pres.layout` 必须先设、不要复用 options 对象、阴影 offset 必须 ≥ 0、堆叠图 `dataLabelPosition` 不能用 `outEnd` 等）**全部以 `pptx/SKILL.md` 为准**，这里不重复。

## 7. 边界情况

| 情况 | 处理 |
|---|---|
| 主题涉及实时信息（股价、疫情、赛事） | 检索结果标注检索时刻，并在成品里注明"数据截至 <日期>" |
| 检索几乎搜不到内容 | 停下来告诉用户，列出你搜过的查询词，问是否换角度或换主题。**不要靠记忆硬编一版** |
| 检索结果互相矛盾 | 两方并列呈现，写成"争议"页，不要替用户选边 |
| 用户给了参考文件/已有 PPT | 先读它，沿用其结构与口径；改现有 PPT 走 pptx 技能的"编辑"路径，不是重做 |
| 主题是敏感或涉政内容 | 只客观呈现可核实的事实与多方观点，不做价值判断 |
| 用户中途改主题 | 新主题视为新任务，重新走 ② 检索，不要复用旧素材 |
| 依赖装不上（npm / pip 失败） | 如实报告失败原因和报错原文，问用户是否继续；不要静默降级成手写一段 XML 假装做完了 |
